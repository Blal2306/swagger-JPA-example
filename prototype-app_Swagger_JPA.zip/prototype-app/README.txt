SWAGGER URL
***********
http://localhost:8080/swagger-ui.html


PUBLISH A PAYLOAD
******************

{
  "description": "Recipe 23",
  "cookTime": 21,
  "servings": 4,
  "source": "Source 21",
  "url": "URL 21",
  "directions": "Recipe 21 - Directions",
  "ingredients": [
    {
      "description": "Recipe 21 - Ingredient 2",
      "amount": 6
    },
    {
      "description": "Recipe 21 - Ingredient 3",
      "amount": 8
    },
    {
      "description": "Recipe 21 - Ingredient 1",
      "amount": 11
    }
  ],
  "image": "AQIDBAU=",
  "difficulty": "MODERATE",
  "notes": {
    "recipeNotes": "Recipe 21 - Notes"
  },
  "categories": [
    {
      "description": "Chinese"
    },
    {
      "description": "American"
    }
  ],
  "prep_time_in_minutes": 11
}