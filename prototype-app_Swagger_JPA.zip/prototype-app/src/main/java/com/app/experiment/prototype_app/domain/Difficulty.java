package com.app.experiment.prototype_app.domain;

public enum Difficulty {
    EASY, MODERATE, HARD
}
