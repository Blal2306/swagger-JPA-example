package com.app.experiment.prototype_app.service;

@FunctionalInterface
public interface hello {
    public void sayHello();
}
