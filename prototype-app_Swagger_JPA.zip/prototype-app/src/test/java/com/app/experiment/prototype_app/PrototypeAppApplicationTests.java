package com.app.experiment.prototype_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrototypeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
